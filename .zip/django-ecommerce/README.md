# django-ecommerce
E-Commerce Project build in Django 2.1.7

This is some picture of the application
<ul>
  <li>Product List
    <img src="demo_pict/pict1.png"/><br><br>
  </li>
  <li>Cart List
    <img src="demo_pict/pict2.png"/><br><br>
  </li>
  <li>Checkout Process
    <img src="demo_pict/pict3.png"/><br><br>
  </li>
</ul>
